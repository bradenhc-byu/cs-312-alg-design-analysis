﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace _2_convex_hull
{
    class ConvexHull
    {
        // class domain variables
        private List<PointF> points;
        private PointF leftmost;
        private PointF rightmost;

        // constructors
        public ConvexHull()
        {
            this.points = new List<PointF>();
            this.leftmost = new PointF();
            this.rightmost = new PointF();
        }

        public ConvexHull(List<PointF> points)
        {
            this.points = points;
            this.setLeftmost();
            this.setRightmost();
        }

        // getters and setters
        public List<PointF> getHull() {return this.points;}
        public PointF getPoint(int index) {return this.points[index];}
        public int getSize() {return this.points.Count;}
        public PointF getLeftmost() {return this.leftmost;}
        public PointF getRightmost() {return this.rightmost;}
        public void setHull(List<PointF> points) { this.points = points; }
        public void setLeftmost() { this.leftmost = this.points[0]; }
        public void setRightmost()
        {
            // this function searches the list of points in the hull to
            // find the furthest right by x value ( O(n) )
            PointF maxRight = this.points[0];
            for (int i = 0; i < this.getSize(); i++)
            {
                if (this.points[i].X >= maxRight.X)
                {
                    maxRight = this.points[i];
                    continue;
                }
                break;
            }
            this.rightmost = maxRight;
        }

        // function to calculate the slope between two points
        public double getSlope(PointF p1, PointF p2)
        {
            return (p2.Y - p1.Y) / (p2.X - p1.X);
        }

        // functions used in hull merge implementation to find the next
        // point in the hull moving clockwise or counter-clockwise
        public int getNextIndex(int currentIndex)
        {
            currentIndex++;
            if (currentIndex >= this.getSize()) currentIndex = 0;
            return currentIndex;
        }
        public int getPrevIndex(int currentIndex)
        {
            currentIndex--;
            if (currentIndex < 0) currentIndex = this.getSize() - 1;
            return currentIndex;
        }

        


        // *****************************************************************************************
        // *****************************************************************************************
        // MERGE FUNCTION : merges two convex hulls together
        //
        public ConvexHull merge(ConvexHull mergeHull)
        {
            if (mergeHull == null) return this;

            // find the upper tangent points
            Tuple<int,int> upperResult = findUpperTangent(this, mergeHull);
            int upperLeft = upperResult.Item1;
            int upperRight = upperResult.Item2;

            // find the lower tangent points
            Tuple<int, int> lowerResult = findLowerTangent(this, mergeHull);          
            int lowerLeft = lowerResult.Item1;
            int lowerRight = lowerResult.Item2;
            
            // using these values, create the new hull
            List<PointF> newHullList = new List<PointF>();

            // starting at the leftmost point of this hull, move clockwise
            // until we reach the upperLeft point
            int curIndex = this.points.IndexOf(this.leftmost);
            while(curIndex != upperLeft)
            {
                newHullList.Add(this.getPoint(curIndex));
                curIndex = Math.Abs((curIndex + 1) % this.getSize());
            }
            newHullList.Add(this.getPoint(curIndex));

            // jump to the mergeHull, add points from upperRight to lowerRight
            curIndex = upperRight;
            while(curIndex != lowerRight)
            {
                newHullList.Add(mergeHull.getPoint(curIndex));
                curIndex = Math.Abs((curIndex + 1) % mergeHull.getSize());
            }
            newHullList.Add(mergeHull.getPoint(curIndex));

            // jump to this hull, finish adding points from lowerLeft
            curIndex = lowerLeft;
            while (curIndex != this.points.IndexOf(this.leftmost))
            {
                newHullList.Add(this.points[curIndex]);
                curIndex = Math.Abs((curIndex + 1) % this.getSize());
            }
            if(curIndex == lowerLeft && curIndex != this.points.IndexOf(this.leftmost))
                newHullList.Add(this.getPoint(curIndex));

            // construct a new convex hull
            ConvexHull hull = new ConvexHull(newHullList);

            return hull;
            
        }

        public Tuple<int,int> findUpperTangent(ConvexHull leftHull, ConvexHull rightHull)
        {
            // set up the flags
            bool foundLeftTop = false;
            bool foundRightTop = false;
            // find the initial leftmost and rightmost points on the left and right 
            // hull respectively
            int upperLeft = leftHull.getHull().IndexOf(leftHull.getRightmost());
            int upperRight = rightHull.getHull().IndexOf(rightHull.getLeftmost());

            // calculate the starting slope
            double currentSlope = getSlope(leftHull.getPoint(upperLeft), rightHull.getPoint(upperRight));

            // until the upper tangent is found
            while(!foundLeftTop || !foundRightTop)
            {
                // while the slope continues to decrease for the left hull point
                while (!foundLeftTop)
                {
                    // move the left hull point counter-clockwise
                    upperLeft = leftHull.getPrevIndex(upperLeft);
                    // recalculate the slope
                    double newSlope = getSlope(leftHull.getPoint(upperLeft), rightHull.getPoint(upperRight));
                    // compare the new slope with the old
                    if(newSlope < currentSlope)
                    {
                        // the slope decreased, keep looking for the upper tangent
                        foundRightTop = false;
                        currentSlope = newSlope;
                    }
                    else
                    {
                        // the slope increased, set the flag for the left hull and then
                        // check to see if the right hull upper tangent has been found too
                        foundLeftTop = true;
                        upperLeft = leftHull.getNextIndex(upperLeft);
                    }
                }

                // while the slope keeps increasing for the right hull point
                while (!foundRightTop)
                {
                    // move the right hull point clockwise
                    upperRight = rightHull.getNextIndex(upperRight);
                    // calculate the slope
                    double newSlope = getSlope(leftHull.getPoint(upperLeft), rightHull.getPoint(upperRight));
                    // compare the new slope to the old
                    if(newSlope > currentSlope)
                    {
                        // the slope increased, keep looking for the upper tangent
                        foundLeftTop = false;
                        currentSlope = newSlope;
                    }
                    else
                    {
                        // the slope decreased, set the flag for the right hull and then
                        // check to see if the left hull upper tangent has been found too
                        foundRightTop = true;
                        upperRight = rightHull.getPrevIndex(upperRight);
                    }
                }
            }

            // both hull points complete the upper tangent, return them
            return new Tuple<int, int>(upperLeft, upperRight);

        }

        public Tuple<int, int> findLowerTangent(ConvexHull leftHull, ConvexHull rightHull)
        {
            // set up the flags for finding the lower tangent
            bool foundLeftBottom = false;
            bool foundRightBottom = false;
            // find the initial leftmost and rightmost points of the left 
            // and right hulls respectively
            int lowerLeft = leftHull.getHull().IndexOf(leftHull.getRightmost());
            int lowerRight = rightHull.getHull().IndexOf(rightHull.getLeftmost());
            // calculate the initial slope
            double currentSlope = getSlope(leftHull.getPoint(lowerLeft), rightHull.getPoint(lowerRight));

            // while the lower tangent has not been found
            while (!foundLeftBottom || !foundRightBottom)
            {
                // while the left hull point continues to increase in slope
                while (!foundLeftBottom)
                {
                    // move the left hull point clockwise
                    lowerLeft = leftHull.getNextIndex(lowerLeft);
                    // calculate the new slope and compare it with the old
                    double newSlope = getSlope(leftHull.getPoint(lowerLeft), rightHull.getPoint(lowerRight));
                    if (newSlope > currentSlope)
                    {
                        // the slope increased, continue searching for the lower tangent
                        foundRightBottom = false;
                        currentSlope = newSlope;
                    }
                    else
                    {
                        // the slope decreased, set the flag for the left bottom tangent and
                        // keep check to make sure the right tangent has been found too
                        foundLeftBottom = true;
                        lowerLeft = leftHull.getPrevIndex(lowerLeft);
                    }
                }

                // while the right hull point continues to decrease in slope
                while (!foundRightBottom)
                {
                    // move the right hull point counter-clockwise
                    lowerRight = rightHull.getPrevIndex(lowerRight);
                    // calculate the new slope and compare it with the old
                    double newSlope = getSlope(leftHull.getPoint(lowerLeft), rightHull.getPoint(lowerRight));
                    if (newSlope < currentSlope)
                    {
                        // the slope decreased, continue looking for the lower tangent
                        foundLeftBottom = false;
                        currentSlope = newSlope;
                    }
                    else
                    {
                        // the slope increased, set the flag for the right hull and check
                        // to see if the left hull has found the lower tangent as well
                        foundRightBottom = true;
                        lowerRight = rightHull.getNextIndex(lowerRight);
                    }
                }
            }

            // once both points to the lower tangent are found, return them
            return new Tuple<int, int>(lowerLeft, lowerRight);

        }

    }
}
