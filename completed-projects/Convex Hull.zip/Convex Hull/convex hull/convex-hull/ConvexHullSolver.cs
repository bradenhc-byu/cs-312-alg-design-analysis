using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace _2_convex_hull
{
    class ConvexHullSolver
    {
        static System.Drawing.Graphics g;
        static System.Windows.Forms.PictureBox pictureBoxView;

        public ConvexHullSolver(System.Drawing.Graphics gr, System.Windows.Forms.PictureBox pictureBoxViewer)
        {
            g = gr;
            pictureBoxView = pictureBoxViewer;
        }

        public void Refresh()
        {
            // Use this especially for debugging and whenever you want to see 
            // what you have drawn so far
            pictureBoxView.Refresh();
        }

        public void Pause(int milliseconds)
        {
            // Use this especially for debugging and to animate your algorithm slowly
            pictureBoxView.Refresh();
            System.Threading.Thread.Sleep(milliseconds);
        }

        public void drawHull(List<PointF> hull,Pen lineColor)
        {
            // transfrom the list of PointF into an array and draw connecting lines 
            // between the points
            if (hull.Count < 2) return;
            PointF[] hullArray = hull.ToArray();
            g.DrawLines(lineColor, hullArray);
            g.DrawLine(lineColor, hullArray[0], hullArray[hull.Count - 1]);
        }

        public void drawLine(PointF p1, PointF p2, Pen lineColor)
        {
            if (p1 == p2) return;
            g.DrawLine(lineColor, p1, p2);
        }

        // *************************************************************************
        // *************************************************************************
        // Function to find the convex hull of a set of points
        // Using the master theorem and an overall analysis of the complexity of this  
        // algorithm, we have found the big-O complexity to be:
        //                O(n log n)
        //
        public void Solve(List<System.Drawing.PointF> pointList)
        {
            // find the size of the list and its first two halves ( O(1) )
            int listSize = pointList.Count;
            if (listSize < 2) return;
            int firstHalfSize = listSize / 2;
            int lastHalfSize = listSize - firstHalfSize;

            // sort the list by its X values using a mergesort ( O(n log n) )
            pointList.Sort((p1,p2) => p1.X.CompareTo(p2.X));

            // recursively find the left and right hulls sub hulls
            // using the master theorem we have O(n log n)
            ConvexHull leftHull = findHull(pointList.GetRange(0, firstHalfSize));
            ConvexHull rightHull = findHull(pointList.GetRange(firstHalfSize, lastHalfSize));

            // merge the two sub-hulls to find the convex hull
            ConvexHull completeHull = leftHull.merge(rightHull);

            // draw the hull
            Pen bluePen = new Pen(Color.Blue, 2f);
            drawHull(completeHull.getHull(), bluePen);

        }

        public ConvexHull findHull(List<PointF> pointList)
        {
            // base case : there is only one point in the list
            if (pointList.Count == 1) return new ConvexHull(pointList);

            // more than one point in the list, split it in two and recurse
            int listSize = pointList.Count;
            int firstHalfSize = listSize / 2;
            int lastHalfSize = listSize - firstHalfSize;

            // recursivesly find the left and right sub hulls
            ConvexHull leftHull = findHull(pointList.GetRange(0, firstHalfSize));
            ConvexHull rightHull = findHull(pointList.GetRange(firstHalfSize, lastHalfSize));

            // merge the two sub hulls together
            ConvexHull mergedHull = leftHull.merge(rightHull);

            // set the left and rightmost points of the new hull
            mergedHull.setLeftmost();
            mergedHull.setRightmost();

            return mergedHull;
        }

        public void printListContents(List<PointF> pointList,string type)
        {
            Console.WriteLine("{0} List Points:",type);

            foreach (PointF point in pointList)
            {
                Console.WriteLine(" {0},{1}", point.X, point.Y);
            }
        }

        public static void printPoint(PointF p, string title)
        {
            Console.WriteLine("{0} : {1},{2}", title, p.X, p.Y);
        }
    }
}
