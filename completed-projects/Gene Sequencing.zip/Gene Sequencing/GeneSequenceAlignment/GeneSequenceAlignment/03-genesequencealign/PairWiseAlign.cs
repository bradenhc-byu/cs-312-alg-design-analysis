using System;
using System.Collections.Generic;
using System.Text;

namespace GeneticsLab
{
    class PairWiseAlign
    {
        int MaxCharactersToAlign;
        int indelCost;
        int subCost;
        int matchCost;
        int bandDistance;

        public PairWiseAlign()
        {
            // Default is to align only 5000 characters in each sequence.
            this.MaxCharactersToAlign = 5000;
            this.indelCost = 5;
            this.subCost = 1;
            this.matchCost = -3;
            this.bandDistance = 3;
        }

        public PairWiseAlign(int len)
        {
            // Alternatively, we can use an different length; typically used with the banded option checked.
            this.MaxCharactersToAlign = len;
            this.indelCost = 5;
            this.subCost = 1;
            this.matchCost = -3;
            this.bandDistance = 3;
        }

        /// <summary>
        /// this is the function you implement.
        /// </summary>
        /// <param name="sequenceA">the first sequence</param>
        /// <param name="sequenceB">the second sequence, may have length not equal to the length of the first seq.</param>
        /// <param name="banded">true if alignment should be band limited.</param>
        /// <returns>the alignment score and the alignment (in a Result object) for sequenceA and sequenceB.  The calling function places the result in the dispay appropriately.
        /// 
        public ResultTable.Result Align_And_Extract(GeneSequence sequenceA, GeneSequence sequenceB, bool banded)
        {
            ResultTable.Result result = new ResultTable.Result();
            int score;                                                       // place your computed alignment score here
            string[] alignment = new string[2];                              // place your two computed alignments here
            // Initialize the table width and height so that they are not greater than the k value
            int tableWidth = (sequenceA.Sequence.Length >= MaxCharactersToAlign) ? MaxCharactersToAlign : sequenceA.Sequence.Length;
            int tableHeight = (sequenceB.Sequence.Length >= MaxCharactersToAlign) ? MaxCharactersToAlign : sequenceB.Sequence.Length;
            // Create tables to store the scores and pointers
            int[,] scoreTable = new int[tableHeight + 1, tableWidth + 1];
            char[,] pointerTable = new char[tableHeight + 1, tableWidth + 1];
            // Initialize stringbuilders to use when determining the optimal alignment
            StringBuilder alignment1 = new StringBuilder();
            StringBuilder alignment2 = new StringBuilder();

            scoreTable[0,0] = 0;           // initialize the score table first spot to 0
            pointerTable[0,0] = 's';       // initialize the pointer table first spot to 's' (start)

            if (banded) {
                // BANDED ALGORITHM
                // Overall Time Complexity: O(2(n + m)) = O(n + m)
                // Overall Space Complexity: O(2nm) = O(nm)
                // If the lengths of the sequences are outisde the limits, stop and report that no alignment can be found
                if ((Math.Abs(sequenceA.Sequence.Length - sequenceB.Sequence.Length)) > (this.bandDistance * tableWidth)) {
                    scoreTable[tableHeight, tableWidth] = int.MaxValue;
                    alignment1.Append("No Alignment Possible");
                    alignment2.Append("No Alignment Possible");
                }
                else {
                    // Fill the cost table and the pointer table (at the same time)
                    // O( n + m )
                    for (int row = 0; row <= tableHeight; row++) {
                        // Set up the band so that we do not bother filling the table outside of
                        // the band distance (which is 3)
                        int bandStart = ((row - this.bandDistance - 1 < 0) ? 0 : row - this.bandDistance - 1);
                        int bandEnd = ((row + this.bandDistance + 1 > tableWidth) ? tableWidth : row + this.bandDistance + 1);
                        for (int col = bandStart; col <= bandEnd; col++) {
                            // Already initialized [0,0], so skip
                            if (row == 0 && col == 0) continue;
                            // Set the entries just outside the band to int.MaxValue - 5
                            else if (col == (row - this.bandDistance - 1) || col == (row + this.bandDistance + 1)) {
                                scoreTable[row, col] = int.MaxValue - this.indelCost;
                                pointerTable[row, col] = 'n';
                            }
                            // Initialize the first row
                            else if (row == 0) {
                                scoreTable[row, col] = scoreTable[row, col - 1] + this.indelCost;
                                pointerTable[row, col] = 'l';
                            }
                            // Initialize the first column
                            else if (col == 0) {
                                scoreTable[row, col] = scoreTable[row - 1, col] + this.indelCost;
                                pointerTable[row, col] = 'u';
                            }
                            // We are within the bands, so do our normal calculations
                            else {
                                // Get the three scores and find the minimum
                                int upScore = scoreTable[row - 1, col] + this.indelCost;
                                int diagScore = ((sequenceA.Sequence[col - 1] == sequenceB.Sequence[row - 1]) ?
                                    (scoreTable[row - 1, col - 1] + this.matchCost) : (scoreTable[row - 1, col - 1] + this.subCost));
                                int leftScore = scoreTable[row, col - 1] + this.indelCost;
                                char pointer = findMinimumScore(upScore, diagScore, leftScore);
                                pointerTable[row, col] = pointer;
                                switch (pointer) {
                                    // The best score comes from an upper indel
                                    case 'u':
                                        scoreTable[row, col] = upScore;
                                        break;
                                    // The best score comes from a match/sub
                                    case 'd':
                                        scoreTable[row, col] = diagScore;
                                        break;
                                    // The best score comes from a left indel
                                    case 'l':
                                        scoreTable[row, col] = leftScore;
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }

                    // We need to backtrack and find the optimal alignment using the pointer table
                    // O( m + n )
                    int curRow = tableHeight;
                    int curCol = tableWidth;
                    while (curRow > 0 || curCol > 0) {
                        switch (pointerTable[curRow, curCol]) {
                            case 'd':
                                alignment1.Insert(0, sequenceA.Sequence[curCol - 1]);
                                alignment2.Insert(0, sequenceB.Sequence[curRow - 1]);
                                curRow--;
                                curCol--;
                                break;
                            case 'u':
                                alignment1.Insert(0, "-");
                                alignment2.Insert(0, sequenceB.Sequence[curRow - 1]);
                                curRow--;
                                break;
                            case 'l':
                                alignment1.Insert(0, sequenceA.Sequence[curCol - 1]);
                                alignment2.Insert(0, "-");
                                curCol--;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            else {
                // UNRESTRICTED ALGORITHM
                // Overall Time Complexity: O(nm + (n + m)) = O(nm)
                // Overall Space Complexity: O(2nm) = O(nm)

                // We need to fill out the score table and pointer table (at the same time for efficiency)
                // O(nm)
                for (int row = 0; row <= tableHeight; row++) {
                    for (int col = 0; col <= tableWidth; col++) {
                        // fill the first row of the table
                        if(row == 0) {
                            if(col != 0) {
                                scoreTable[row,col] = scoreTable[row, col - 1] + this.indelCost;
                                pointerTable[row,col] = 'l';
                            }
                        }
                        // fill the first column of the table
                        else if(col == 0) {
                            if(row != 0) {
                                scoreTable[row,col] = scoreTable[row - 1, col] + this.indelCost;
                                pointerTable[row,col] = 'u';
                            }
                        }
                        // fill the inner values of the table
                        else {
                            int upScore = scoreTable[row - 1,col] + this.indelCost;
                            int diagScore = ((sequenceA.Sequence[col - 1] == sequenceB.Sequence[row - 1]) ?  
                                (scoreTable[row - 1,col - 1] + this.matchCost) : (scoreTable[row - 1,col - 1] + this.subCost));
                            int leftScore = scoreTable[row,col-1] + this.indelCost;
                            char pointer = findMinimumScore(upScore, diagScore, leftScore);
                            pointerTable[row,col] = pointer;
                            switch (pointer) {
                                // The best score comes from an upper indel
                                case 'u':
                                    scoreTable[row,col] = upScore;
                                    break;
                                // The best score comes from a match/sub
                                case 'd':
                                    scoreTable[row,col] = diagScore;
                                    break;
                                // The best score comes from a left indel
                                case 'l':
                                    scoreTable[row,col] = leftScore;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }

                // Now we need to backtrack and find the optimal alignment 
                // O(n + m)
                int curRow = tableHeight;
                int curCol = tableWidth;
                score = scoreTable[curRow,curCol];
                while(curRow > 0 || curCol > 0) {
                    switch (pointerTable[curRow,curCol]) {
                        case 'd':
                            alignment1.Insert(0,sequenceA.Sequence[curCol - 1]);
                            alignment2.Insert(0,sequenceB.Sequence[curRow - 1]);
                            curRow--;
                            curCol--;
                            break;
                        case 'u':
                            alignment1.Insert(0,"-");
                            alignment2.Insert(0,sequenceB.Sequence[curRow - 1]);
                            curRow--;
                            break;
                        case 'l':
                            alignment1.Insert(0,sequenceA.Sequence[curCol - 1]);
                            alignment2.Insert(0,"-");
                            curCol--;
                            break;
                        default:
                            break;
                    }
                }
                

            } // end of banded check


            // ********* Assign the placeholder values ***********************************************
             score = scoreTable[tableHeight,tableWidth];
             alignment[0] = alignment1.ToString();
             alignment[1] = alignment2.ToString();
            // ***************************************************************************************
            
            if(score == -6820) {
                Console.WriteLine(alignment1.ToString().Substring(0,100));
                Console.WriteLine(alignment2.ToString().Substring(0,100));
            }

            result.Update(score,alignment[0],alignment[1]);                  // bundling your results into the right object type 
            return(result);
        }

        // Method to compute the minimum score: returns the corresponding pointer direction
        // O(1)
        private char findMinimumScore(int upScore, int diagScore, int leftScore) {
            int minScore = Math.Min(upScore, Math.Min(diagScore, leftScore));
            if (minScore == upScore) return 'u';
            if (minScore == diagScore) return 'd';
            if (minScore == leftScore) return 'l';
            return 'n';
        }

        // debugging
        private void printScoreTable(int[,] scoreTable, int tableHeight, int tableWidth) {
            // DEBUGGING: print score table
            for (int row = 0; row <= tableHeight; row++) {
                for (int col = 0; col <= tableWidth; col++) {
                    Console.Write(scoreTable[row, col] + "       ");
                }
                Console.Write("\n");
            }
        }


    }
}
