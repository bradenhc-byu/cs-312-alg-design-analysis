﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP {
    class PQueue {

        // The queue of states where the higher priority
        // elements are towards the front
        private List<State> queue;
        public List<State> Queue {
            get { return queue; }
            set { queue = value; }
        }

        // Default Constructor
        public PQueue() {
            this.queue = new List<State>();
        }

        // Methods for pushing and popping
        public void pushState(State state) {
            state.QueueIndex = this.queue.Count;
            this.queue.Add(state);
            while (needsShiftUp(state)) {
                State parent = getPQState(state.QueueIndex / 2);
                if (parent != null)
                    swapState(state, parent);
            }
        }

        public State popState() {
            if (size() < 1) return null;
            if (this.queue.Count > 1) {
                // Save the min node
                State min = getPQState(0);
                // Set the new root to the last element in the queue
                State newMin = getPQState(this.queue.Count - 1);
                newMin.QueueIndex = 0;
                this.queue[0] = newMin;
                // Remove the last element
                this.queue.RemoveAt(this.queue.Count - 1);
                // If the child nodes have costs lower than this node, shift
                while (needsShiftDown(newMin)) {
                    if (needShiftLeft(newMin)) {
                        State leftChild = getPQState(newMin.QueueIndex * 2);
                        if (leftChild != null) 
                            swapState(leftChild, newMin);
                    }
                    else if (needShiftRight(newMin)) {
                        State rightChild = getPQState(newMin.QueueIndex * 2 + 1);
                        if (rightChild != null)
                            swapState(rightChild, newMin);
                    }
                }
                return min;
            }
            else {
                // Save the min node
                State min = getPQState(0);
                this.queue.RemoveAt(0);
                return min;
            }
        }

        // *************************************************************************
        // Determines if the cost of the given node is less than its children's cost
        // return true if the cost is greater, false otherwise
        //
        private Boolean needsShiftDown(State state) {
            if (state == null) return false;
            State leftChild = getPQState(state.QueueIndex * 2);
            State rightChild = getPQState(state.QueueIndex * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return rightChild.PRatio > state.PRatio;
            if (rightChild == null) return leftChild.PRatio > state.PRatio;
            return (leftChild.PRatio > state.PRatio) || (rightChild.PRatio > state.PRatio);
        }

        // ************************************************************************
        // Once we determine the node needs to shift down, determine if the node
        // needs to shift to the left
        // returns true if the node needs to replace the left child, false otherwise
        private Boolean needShiftLeft(State state) {
            State leftChild = getPQState(state.QueueIndex * 2);
            State rightChild = getPQState(state.QueueIndex * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return false;
            if (rightChild == null) return true;
            if (rightChild.PRatio == leftChild.PRatio) return true;
            return leftChild.PRatio > rightChild.PRatio;
        }

        // ************************************************************************
        // Once we determine the node needs to shift down, determine if the node
        // needs to shift to the right
        // returns true if the node needs to replace the right child, false otherwise
        private Boolean needShiftRight(State state) {
            State leftChild = getPQState(state.QueueIndex * 2);
            State rightChild = getPQState(state.QueueIndex * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return true;
            if (rightChild == null) return false;
            if (rightChild.PRatio == leftChild.PRatio) return true;
            return leftChild.PRatio < rightChild.PRatio;
        }

        // ***************************************************************
        // Determines of the parent node of the given node has a greater cost
        // returns true if the parent node cost is greater, false otherwise
        //
        private Boolean needsShiftUp(State state) {
            if (state == null) return false;
            if (state.QueueIndex == 0) return false; // it's the root
            State parent = getPQState(state.QueueIndex / 2);
            if (parent == null) return false;
            return parent.PRatio < state.PRatio;
        }

        private State getPQState(int index) {
            if (index < 0 || index >= this.queue.Count) return null;
            return this.queue[index];
        }

        private void swapState(State child, State parent) {
            int parentIndex = parent.QueueIndex;
            parent.QueueIndex = child.QueueIndex;
            child.QueueIndex = parentIndex;
            this.queue[child.QueueIndex] = child;
            this.queue[parent.QueueIndex] = parent;
        }

        public void clear() {
            this.queue.Clear();
        }

        public int size() {
            return this.queue.Count;
        }
    }
}
