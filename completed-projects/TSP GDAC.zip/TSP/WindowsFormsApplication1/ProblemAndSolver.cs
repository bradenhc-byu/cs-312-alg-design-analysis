using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Timers;
using System.Linq;

namespace TSP
{

    class ProblemAndSolver
    {

        #region Private members 

        /// <summary>
        /// Default number of cities (unused -- to set defaults, change the values in the GUI form)
        /// </summary>
        // (This is no longer used -- to set default values, edit the form directly.  Open Form1.cs,
        // click on the Problem Size text box, go to the Properties window (lower right corner), 
        // and change the "Text" value.)
        private const int DEFAULT_SIZE = 25;

        /// <summary>
        /// Default time limit (unused -- to set defaults, change the values in the GUI form)
        /// </summary>
        // (This is no longer used -- to set default values, edit the form directly.  Open Form1.cs,
        // click on the Time text box, go to the Properties window (lower right corner), 
        // and change the "Text" value.)
        private const int TIME_LIMIT = 60;        //in seconds

        private const int CITY_ICON_SIZE = 5;


        // For normal and hard modes:
        // hard mode only
        private const double FRACTION_OF_PATHS_TO_REMOVE = 0.20;

        /// <summary>
        /// the cities in the current problem.
        /// </summary>
        private City[] Cities;
        /// <summary>
        /// a route through the current problem, useful as a temporary variable. 
        /// </summary>
        private ArrayList Route;
        /// <summary>
        /// best solution so far. 
        /// </summary>
        private TSPSolution bssf; 

        /// <summary>
        /// how to color various things. 
        /// </summary>
        private Brush cityBrushStartStyle;
        private Brush cityBrushStyle;
        private Pen routePenStyle;


        /// <summary>
        /// keep track of the seed value so that the same sequence of problems can be 
        /// regenerated next time the generator is run. 
        /// </summary>
        private int _seed;
        /// <summary>
        /// number of cities to include in a problem. 
        /// </summary>
        private int _size;

        /// <summary>
        /// Difficulty level
        /// </summary>
        private HardMode.Modes _mode;

        /// <summary>
        /// random number generator. 
        /// </summary>
        private Random rnd;

        /// <summary>
        /// time limit in milliseconds for state space search
        /// can be used by any solver method to truncate the search and return the BSSF
        /// </summary>
        private int time_limit;
        #endregion

        #region Public members

        /// <summary>
        /// These three constants are used for convenience/clarity in populating and accessing the results array that is passed back to the calling Form
        /// </summary>
        public const int COST = 0;           
        public const int TIME = 1;
        public const int COUNT = 2;
        
        public int Size
        {
            get { return _size; }
        }

        public int Seed
        {
            get { return _seed; }
        }
        #endregion

        #region Constructors
        public ProblemAndSolver()
        {
            this._seed = 1; 
            rnd = new Random(1);
            this._size = DEFAULT_SIZE;
            this.time_limit = TIME_LIMIT * 1000;                  // TIME_LIMIT is in seconds, but timer wants it in milliseconds

            this.resetData();
        }

        public ProblemAndSolver(int seed)
        {
            this._seed = seed;
            rnd = new Random(seed);
            this._size = DEFAULT_SIZE;
            this.time_limit = TIME_LIMIT * 1000;                  // TIME_LIMIT is in seconds, but timer wants it in milliseconds

            this.resetData();
        }

        public ProblemAndSolver(int seed, int size)
        {
            this._seed = seed;
            this._size = size;
            rnd = new Random(seed);
            this.time_limit = TIME_LIMIT * 1000;                        // TIME_LIMIT is in seconds, but timer wants it in milliseconds

            this.resetData();
        }
        public ProblemAndSolver(int seed, int size, int time)
        {
            this._seed = seed;
            this._size = size;
            rnd = new Random(seed);
            this.time_limit = time*1000;                        // time is entered in the GUI in seconds, but timer wants it in milliseconds

            this.resetData();
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Reset the problem instance.
        /// </summary>
        private void resetData()
        {

            Cities = new City[_size];
            Route = new ArrayList(_size);
            bssf = null;

            if (_mode == HardMode.Modes.Easy)
            {
                for (int i = 0; i < _size; i++)
                    Cities[i] = new City(rnd.NextDouble(), rnd.NextDouble());
            }
            else // Medium and hard
            {
                for (int i = 0; i < _size; i++)
                    Cities[i] = new City(rnd.NextDouble(), rnd.NextDouble(), rnd.NextDouble() * City.MAX_ELEVATION);
            }

            HardMode mm = new HardMode(this._mode, this.rnd, Cities);
            if (_mode == HardMode.Modes.Hard)
            {
                int edgesToRemove = (int)(_size * FRACTION_OF_PATHS_TO_REMOVE);
                mm.removePaths(edgesToRemove);
            }
            City.setModeManager(mm);

            cityBrushStyle = new SolidBrush(Color.Black);
            cityBrushStartStyle = new SolidBrush(Color.Red);
            routePenStyle = new Pen(Color.Blue,1);
            routePenStyle.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// make a new problem with the given size.
        /// </summary>
        /// <param name="size">number of cities</param>
        public void GenerateProblem(int size, HardMode.Modes mode)
        {
            this._size = size;
            this._mode = mode;
            resetData();
        }

        /// <summary>
        /// make a new problem with the given size, now including timelimit paremeter that was added to form.
        /// </summary>
        /// <param name="size">number of cities</param>
        public void GenerateProblem(int size, HardMode.Modes mode, int timelimit)
        {
            this._size = size;
            this._mode = mode;
            this.time_limit = timelimit*1000;                                   //convert seconds to milliseconds
            resetData();
        }

        /// <summary>
        /// return a copy of the cities in this problem. 
        /// </summary>
        /// <returns>array of cities</returns>
        public City[] GetCities()
        {
            City[] retCities = new City[Cities.Length];
            Array.Copy(Cities, retCities, Cities.Length);
            return retCities;
        }

        /// <summary>
        /// draw the cities in the problem.  if the bssf member is defined, then
        /// draw that too. 
        /// </summary>
        /// <param name="g">where to draw the stuff</param>
        public void Draw(Graphics g)
        {
            float width  = g.VisibleClipBounds.Width-45F;
            float height = g.VisibleClipBounds.Height-45F;
            Font labelFont = new Font("Arial", 10);

            // Draw lines
            if (bssf != null)
            {
                // make a list of points. 
                Point[] ps = new Point[bssf.Route.Count];
                int index = 0;
                foreach (City c in bssf.Route)
                {
                    if (index < bssf.Route.Count -1)
                        g.DrawString(" " + index +"("+c.costToGetTo(bssf.Route[index+1]as City)+")", labelFont, cityBrushStartStyle, new PointF((float)c.X * width + 3F, (float)c.Y * height));
                    else 
                        g.DrawString(" " + index +"("+c.costToGetTo(bssf.Route[0]as City)+")", labelFont, cityBrushStartStyle, new PointF((float)c.X * width + 3F, (float)c.Y * height));
                    ps[index++] = new Point((int)(c.X * width) + CITY_ICON_SIZE / 2, (int)(c.Y * height) + CITY_ICON_SIZE / 2);
                }

                if (ps.Length > 0)
                {
                    g.DrawLines(routePenStyle, ps);
                    g.FillEllipse(cityBrushStartStyle, (float)Cities[0].X * width - 1, (float)Cities[0].Y * height - 1, CITY_ICON_SIZE + 2, CITY_ICON_SIZE + 2);
                }

                // draw the last line. 
                g.DrawLine(routePenStyle, ps[0], ps[ps.Length - 1]);
            }

            // Draw city dots
            foreach (City c in Cities)
            {
                g.FillEllipse(cityBrushStyle, (float)c.X * width, (float)c.Y * height, CITY_ICON_SIZE, CITY_ICON_SIZE);
            }

        }

        /// <summary>
        ///  return the cost of the best solution so far. 
        /// </summary>
        /// <returns></returns>
        public double costOfBssf ()
        {
            if (bssf != null)
                return (bssf.costOfRoute());
            else
                return -1D; 
        }

        /// <summary>
        /// This is the entry point for the default solver
        /// which just finds a valid random tour 
        /// </summary>
        /// <returns>results array for GUI that contains three ints: cost of solution, time spent to find solution, number of solutions found during search (not counting initial BSSF estimate)</returns>
        public string[] defaultSolveProblem()
        {
            int i, swap, temp, count=0;
            string[] results = new string[3];
            int[] perm = new int[Cities.Length];
            Route = new ArrayList();
            Random rnd = new Random();
            Stopwatch timer = new Stopwatch();

            timer.Start();

            do
            {
                for (i = 0; i < perm.Length; i++)                                 // create a random permutation template
                    perm[i] = i;
                for (i = 0; i < perm.Length; i++)
                {
                    swap = i;
                    while (swap == i)
                        swap = rnd.Next(0, Cities.Length);
                    temp = perm[i];
                    perm[i] = perm[swap];
                    perm[swap] = temp;
                }
                Route.Clear();
                for (i = 0; i < Cities.Length; i++)                            // Now build the route using the random permutation 
                {
                    Route.Add(Cities[perm[i]]);
                }
                bssf = new TSPSolution(Route);
                count++;
            } while (costOfBssf() == double.PositiveInfinity);                // until a valid route is found
            timer.Stop();

            results[COST] = costOfBssf().ToString();                          // load results array
            results[TIME] = timer.Elapsed.ToString();
            results[COUNT] = count.ToString();

            return results;
        }

        /// <summary>
        /// performs a Branch and Bound search of the state space of partial tours
        /// stops when time limit expires and uses BSSF as solution
        /// </summary>
        /// <returns>results array for GUI that contains three ints: cost of solution, time spent to find solution, number of solutions found during search (not counting initial BSSF estimate)</returns>

        private PQueue pQueue = new PQueue();
        private int stateCount = 0;
        private int maxSizeOfQueue = 0;
        private int numPruned = 0;

        public string[] bBSolveProblem()
        {
            string[] results = new string[3];
            int numSolutions = 0;
            Stopwatch timer = new Stopwatch();
            stateCount = 0;
            maxSizeOfQueue = 0;
            numPruned = 0;

            timer.Start();

            // Find an initial BSSF
            greedySolveProblem();
            Route.Clear();
            if (costOfBssf() == -1D) {
                defaultSolveProblem();
                Route.Clear();
            }

            // Calculate the Reduced Cost Matrix
            double[,] startingCostMatrix = getCostMatrix();

            
            // Go through each city as the start city to find the best route
            for (int startCityIndex = 0; startCityIndex < Cities.Length; startCityIndex++) {
                if (timer.Elapsed.TotalMilliseconds >= time_limit) {
                    break;
                }
                pQueue.clear();
                maxSizeOfQueue = 0;
                pQueue.pushState(new State(startCityIndex, startingCostMatrix));
                stateCount++;
                maxSizeOfQueue++;
                // Begin the solution search
                State nextState;
                TSPSolution newBssf;
                while((nextState = pQueue.popState()) != null) {
                    if (timer.Elapsed.TotalMilliseconds >= time_limit) {
                        break;
                    }
                    // Prune through all of the useless states in the queue
                    // Once we find a valid one, use it
                    while(nextState != null && nextState.Bound >= costOfBssf()) {
                        nextState = pQueue.popState();
                        numPruned++;
                    }
                    if (nextState == null) break;
                    // Check to see if the next state is a leaf in the tree
                    if(nextState.Level == Cities.Length - 1) {
                        // Check to see if there is a past from the last city to the first
                        if (!Double.IsPositiveInfinity(Cities[startCityIndex].costToGetTo(Cities[nextState.CityIndex]))) {
                            // Create a new TSPSolution and compare it with the old BSSF
                            newBssf =  new TSPSolution(generateCityRoute(nextState.Route));
                            if (bssf == null) {
                                bssf = newBssf;
                                numSolutions++;
                            }
                            else if (newBssf.costOfRoute() < bssf.costOfRoute()) {
                                bssf = newBssf;
                                numSolutions++;
                            }
                        }
                    }
                    else {
                        // Not a leaf, keep exploring by generating children
                        generateChildren(nextState);
                    }
                }
            }
            timer.Stop();

            Console.WriteLine("States Created: {0}", stateCount);
            Console.WriteLine("Max Size of Queue: {0}", maxSizeOfQueue);
            Console.WriteLine("Pruned States: {0}", numPruned);

            results[COST] = costOfBssf().ToString();    // load results into array here, replacing these dummy values
            results[TIME] = timer.Elapsed.ToString();
            results[COUNT] = numSolutions.ToString();

            return results;
        }

        // ********************************************************************************
        // Function to generate and the original cost matrix
        // returns the non-reduced cost matrix
        //
        private double[,] getCostMatrix() {
            double[,] originalCostMatrix = new double[Cities.Length, Cities.Length];
            // First fill the cost matrix
            for(int row = 0; row < Cities.Length; row++) {
                for(int col = 0; col < Cities.Length; col++) {
                    if(row == col) {
                        originalCostMatrix[row, col] = Double.PositiveInfinity;
                    }
                    else {
                        originalCostMatrix[row, col] = Cities[row].costToGetTo(Cities[col]);
                    }
                }
            }
            return originalCostMatrix;
        }


        // ********************************************************************************
        // Function to generate children of a state and push then onto the PQueue
        //
        private void generateChildren(State parentState) {
            // For every possible city
            for(int i = 0; i < Cities.Length; i++) {
                // If the child city is not already in the route
                if (!parentState.Route.Contains(i)) {
                    // And if there is a path from the parent city to the child city
                    if (!Double.IsPositiveInfinity(Cities[parentState.CityIndex].costToGetTo(Cities[i]))) {
                        // Create a new shild state and place it in the queue
                        State child = new State(parentState, i);
                        pQueue.pushState(child);
                        if (pQueue.size() > maxSizeOfQueue) {
                            maxSizeOfQueue++;
                        }
                        stateCount++;
                    }
                }
            }
        }

        // ********************************************************************************
        // Function to generate the ArrayList of City objects representing a solution
        // from an ordered list of city indexes
        //
        private System.Collections.ArrayList generateCityRoute(ArrayList cityIndexies) {
            ArrayList cities = new ArrayList();
            for(int i = 0; i < cityIndexies.Count; i++) {
                cities.Add(Cities[(int)cityIndexies[i]]);
            }
            return cities;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////
        // These additional solver methods will be implemented as part of the group project.
        ////////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// finds the greedy tour starting from each city and keeps the best (valid) one
        /// </summary>
        /// <returns>results array for GUI that contains three ints: cost of solution, time spent to find solution, number of solutions found during search (not counting initial BSSF estimate)</returns>
        public string[] greedySolveProblem()
        {
            string[] results = new string[3];
            Route = new ArrayList();
            Stopwatch timer = new Stopwatch();
            int numSolutions = 0;
            TSPSolution curRoute;

            timer.Start();

            for(int i = 0; i < Cities.Length; i++) {
                if(timer.Elapsed.TotalMilliseconds > time_limit) {
                    break;
                }
                // Reset the route
                Route.Clear();
                // Create an array of integers to track if a city has been visited or not (0 = not visited, 1 = visited)
                int[] cities = new int[Cities.Length];
                // Add the start city to the solution route and indicate the
                // city has been visited
                Route.Add(Cities[i]);
                cities[i] = 1;
                // Find an optimal solution from this start city (if it exists)
                curRoute = solveTSPGreedy(i, cities);
                if(bssf == null && curRoute != null) {
                    bssf = curRoute;
                    numSolutions++;
                }
                else if(curRoute != null && curRoute.costOfRoute() > bssf.costOfRoute()) {
                    bssf = curRoute;
                    numSolutions++;
                }
            }

            timer.Stop();

            results[COST] = costOfBssf().ToString();    // load results into array here, replacing these dummy values
            results[TIME] = timer.Elapsed.ToString();
            results[COUNT] = numSolutions.ToString();
            
            return results;
        }

        private TSPSolution solveTSPGreedy(int currentCity, int[] visitedCities) {
            if (Route.Count == Cities.Length) {
                if(!Double.IsPositiveInfinity(((City)Route[0]).costToGetTo(((City)Route[Route.Count - 1])))) {
                    return new TSPSolution(Route);
                }
                else {
                    return null;
                }
            }
            double minCostToNext = Double.MaxValue;
            int nextCityIndex = -1;
            for(int i = 0; i < Cities.Length; i++) {
                if (visitedCities[i] == 1) continue;
                if(i != currentCity) {
                    double costToNext = Cities[currentCity].costToGetTo(Cities[i]);
                    if (costToNext < minCostToNext) {
                        nextCityIndex = i;
                        minCostToNext = costToNext;
                    }
                }
            }
            if(visitedCities[nextCityIndex] == 1) {
                return null;
            }
            else {
                visitedCities[nextCityIndex] = 1;
                Route.Add(Cities[nextCityIndex]);
                return solveTSPGreedy(nextCityIndex, visitedCities);
            }
        }


        // ****************************************************************************************
        // ****************************************************************************************
        //
        // GREEDY DIVIDE AND CONQUER (GDAC)
        // - Find initial BSSF with standard greedy approach
        // - Use set cover to partition the set of cities into subsets
        // - Individually solve each subset
        // - Merge subsets using algorithm involving average x and y values of each subset
        // - Determine the final TSPSolution cost
        //
        public string[] fancySolveProblem()
        {
            string[] results = new string[3];
            Stopwatch timer = new Stopwatch();
            Dictionary<int, List<int>> citiesMap = new Dictionary<int, List<int>>();
            List<GDACPartition> subProblems = new List<GDACPartition>();
            int containDistance = 200;
            int numSolutions = 0;

            // Determine initial BSSF
            defaultSolveProblem();
            Route.Clear();
            /*greedySolveProblem();
            Route.Clear();
            if(costOfBssf() == -1D) 
            {
                defaultSolveProblem();
                Route.Clear();
            }*/

            timer.Start();

            Console.WriteLine("Creating distance sets...");
            // Divide into subsets using Set Cover partitioning
            // O(n^2)
            for(int i = 0; i < Cities.Length; i++) 
            {
                List<int> cityPartition = new List<int>();
                cityPartition.Add(i);
                for (int j = 0; j < Cities.Length; j++) 
                {
                    if(i != j && Cities[i].costToGetTo(Cities[j]) <= containDistance) {
                        cityPartition.Add(j);
                    }
                }
                citiesMap.Add(i, cityPartition);
            }

            Console.WriteLine("Solving set cover...");
            // Greedily solve the Set Cover
            int maxCities;
            int maxCityIndex;
            while (!usedAllCities(citiesMap)) {
                maxCities = 0;
                maxCityIndex = -1;
                foreach (KeyValuePair<int, List<int>> partition in citiesMap) {
                    if (partition.Value.Count > maxCities) {
                        maxCityIndex = partition.Value.Count;
                        maxCityIndex = partition.Key;
                    }
                }
                List<int> maxPartition = citiesMap[maxCityIndex];
                GDACPartition gdacPartition = new GDACPartition(maxCityIndex, generateCityList(maxPartition));
                subProblems.Add(gdacPartition);
                citiesMap.Remove(maxCityIndex);
                foreach (KeyValuePair<int, List<int>> partition in citiesMap) {
                    for(int i = 0; i < partition.Value.Count; i++) {
                        if(maxPartition.Contains(partition.Value[i])) {
                            partition.Value.RemoveAt(i);
                            i--;
                        }
                    }
                }
            }


            // The greedy solutions of each subproblem are calculate inside of the object on
            // object instantiation. The average x and y values of each partition are also 
            // calculate when a new GDACPartition object is constructed.

            // Sort by x value
            subProblems.OrderBy(x => x.AverageX);


            Console.WriteLine("Merging partitions....");
            // Start with the leftmost and rightmost partitions
            GDACPartition leftmost;
            GDACPartition rightmost;
            while (subProblems.Count > 1) {
                if (timer.Elapsed.Milliseconds >= time_limit) {
                    subProblems[0].PartitionSolution = null;
                    break;
                }

                // Merge the leftmost with closest partition
                leftmost = subProblems[0];
                int leftmostClosestPartitionIndex = getClosestPartitionIndex(0, subProblems);
                subProblems[0] = leftmost.mergeWith(subProblems[leftmostClosestPartitionIndex]);
                subProblems.RemoveAt(leftmostClosestPartitionIndex);

                // Make sure not all the partitions have been merged
                if (subProblems.Count == 1) {
                    Console.WriteLine("Leftmost merge was last...break from loop...");
                    break;
                }

                // Merge the rightmost with closest partition
                rightmost = subProblems[subProblems.Count - 1];
                int rightmostClosestPartitionIndex = getClosestPartitionIndex(subProblems.Count - 1, subProblems);
                subProblems[subProblems.Count - 1] = rightmost.mergeWith(subProblems[rightmostClosestPartitionIndex]);
                subProblems.RemoveAt(rightmostClosestPartitionIndex);

            }

            Console.WriteLine("Determining BSSF...");
            TSPSolution newBssf = subProblems[0].PartitionSolution;
            if (newBssf != null && newBssf.costOfRoute() < bssf.costOfRoute()) {
                bssf = newBssf;
                numSolutions++;
            }

            timer.Stop();
            Console.WriteLine("Printing results...");

            results[COST] = costOfBssf().ToString();    // load results into array here, replacing these dummy values
            results[TIME] = timer.Elapsed.ToString();
            results[COUNT] = numSolutions.ToString();

            return results;
        }

        // ********************************************************************************
        // Function to generate the ArrayList of City objects representing a solution
        // from an ordered list of city indexes
        //
        private List<City> generateCityList(List<int> cityIndexies) {
            List<City> cities = new List<City>();
            for (int i = 0; i < cityIndexies.Count; i++) {
                cities.Add(Cities[cityIndexies[i]]);
            }
            return cities;
        }


        // ********************************************************************************
        // Determines whether or not all cities have been included in sub-problem partitions
        //
        private bool usedAllCities(Dictionary<int,List<int>> map) {
            foreach(KeyValuePair<int,List<int>> entry in map) {
                if (entry.Value.Count != 0)
                    return false;
            }
            return true;
        }

        // ********************************************************************************
        // Finds the index of the partition closest to the given partition in the subproblem list
        //
        private int getClosestPartitionIndex(int partitionIndex, List<GDACPartition> subproblems) {
            List<City> partitionLocations = new List<City>();
            foreach(GDACPartition partition in subproblems) {
                partitionLocations.Add(new City(partition.AverageX, partition.AverageY));
            }
            double minCost = Double.MaxValue;
            int minCostIndex = -1;
            for(int i = 0; i < partitionLocations.Count; i++) {
                if(i != partitionIndex) {
                    double newCost = partitionLocations[partitionIndex].costToGetTo(partitionLocations[i]);
                    if (newCost < minCost) {
                        minCost = newCost;
                        minCostIndex = i;
                    }
                }
            }
            return minCostIndex;
        }

        #endregion
    }

}
