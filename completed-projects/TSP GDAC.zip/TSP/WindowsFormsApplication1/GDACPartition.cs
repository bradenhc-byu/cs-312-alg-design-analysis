﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP {
    class GDACPartition {

        // The index of the central city for this partition
        int cityIndex;
        public int CityIndex {
            get { return cityIndex; }
            set { cityIndex = value; }
        }

        // The average x value of all cities in the partition
        double averageX;
        public double AverageX {
            get { return averageX; }
            set { averageX = value; }
        }

        // The average y value of all cities in the partition
        double averageY;
        public double AverageY {
            get { return averageY; }
            set { averageY = value; }
        }

        // The list if cities in the partition
        List<City> partitionCities;
        public List<City> PartitionCities {
            get { return partitionCities; }
            set { partitionCities = value; }
        }

        // The TSP solution for this partition
        TSPSolution partitionSolution;
        public TSPSolution PartitionSolution {
            get { return partitionSolution; }
            set { partitionSolution = value; }
        }

        // **********************************************************************
        // Constructors
        //
        public GDACPartition() {
            this.cityIndex = -1;
            this.averageX = 0.0;
            this.averageY = 0.0;
            this.partitionCities = new List<City>();
            this.partitionSolution = null;
        }

        // Contructor that automatically solves the partition greedily and
        // calculates the average x and y values for the set of cities
        public GDACPartition(int cityIndex, List<City> cities) {
            this.cityIndex = cityIndex;
            this.partitionCities = cities;
            determineAverageXY();
            this.partitionSolution = solveGDACPartition();
        }



        // *******************************************************************************
        // *******************************************************************************
        // Returns the average x and y values of a set of cities
        // 
        private void determineAverageXY() {
            foreach (City city in this.partitionCities) {
                this.averageX += city.X;
                this.averageY += city.Y;
            }
            this.averageX = this.averageX / (double)this.partitionCities.Count;
            this.averageY = this.averageY / (double)this.partitionCities.Count;
        }


        // *******************************************************************************
        // *******************************************************************************
        // Returns a TSPSolution using the greedy algorithm on the list of cities in
        // this partition
        // 
        private TSPSolution solveGDACPartition() {
            TSPSolution partitionBssf = null;
            TSPSolution curRoute = null;
            ArrayList cityRoute = new ArrayList();
            for (int i = 0; i < this.partitionCities.Count; i++) {
                // Reset the route
                cityRoute.Clear();
                // Create an array of integers to track if a city has been visited or not (0 = not visited, 1 = visited)
                int[] visitedCities = new int[this.partitionCities.Count];
                // Add the start city to the solution route and indicate the
                // city has been visited
                cityRoute.Add(this.partitionCities[i]);
                visitedCities[i] = 1;
                // Find an optimal solution from this start city (if it exists)
                curRoute = solveTSPGreedy(i, visitedCities, cityRoute);
                if (partitionBssf == null && curRoute != null) {
                    partitionBssf = curRoute;
                }
                else if (curRoute != null && curRoute.costOfRoute() > partitionBssf.costOfRoute()) {
                    partitionBssf = curRoute;
                }
            }

            return partitionBssf;
        }

        // *******************************************************************************
        // *******************************************************************************
        // Recursively find a valid TSP solution for the partition of cities using a 
        // greedy algorithm
        // 
        private TSPSolution solveTSPGreedy(int currentCity, int[] visitedCities, ArrayList curRoute) {
            if (curRoute.Count == this.partitionCities.Count) {
                if (!Double.IsPositiveInfinity(((City)curRoute[0]).costToGetTo(((City)curRoute[curRoute.Count - 1])))) {
                    return new TSPSolution(curRoute);
                }
                else {
                    return null;
                }
            }
            double minCostToNext = Double.MaxValue;
            int nextCityIndex = -1;
            for (int i = 0; i < this.partitionCities.Count; i++) {
                if (visitedCities[i] == 1) continue;
                if (i != currentCity) {
                    double costToNext = this.partitionCities[currentCity].costToGetTo(this.partitionCities[i]);
                    if (costToNext < minCostToNext) {
                        nextCityIndex = i;
                        minCostToNext = costToNext;
                    }
                }
            }
            if (nextCityIndex == -1 || visitedCities[nextCityIndex] == 1) {
                return null;
            }
            else {
                visitedCities[nextCityIndex] = 1;
                curRoute.Add(this.partitionCities[nextCityIndex]);
                return solveTSPGreedy(nextCityIndex, visitedCities, curRoute);
            }
        }

        // *******************************************************************************
        // *******************************************************************************
        // Merges the current partition with another GDACPartition object
        // 
        public GDACPartition mergeWith(GDACPartition mergePartner) {
            TSPSolution partnerSolution = mergePartner.PartitionSolution;
            if(partnerSolution == null || this.partitionSolution == null
                || partnerSolution.Route.Count == 0 || this.partitionSolution.Route.Count == 0) {
                this.partitionCities.AddRange(mergePartner.PartitionCities);
                determineAverageXY();
                this.partitionSolution = solveGDACPartition();
                return this;
            }
            List<City> thisMergeCities = new List<City>();
            thisMergeCities.Add((City)this.partitionSolution.Route[0]);
            if(this.PartitionSolution.Route.Count > 1) {
                thisMergeCities.Add((City)this.partitionSolution.Route[this.partitionSolution.Route.Count - 1]);
            }
            List<City> partnerMergeCities = new List<City>();
            partnerMergeCities.Add((City)partnerSolution.Route[0]);
            if(partnerSolution.Route.Count > 1) {
                partnerMergeCities.Add((City)partnerSolution.Route[partnerSolution.Route.Count - 1]);
            }
            // Determine which two cities to merge
            City thisMergeCity = null;
            City partnerMergeCity = null;
            foreach(City city in thisMergeCities) {
                foreach(City partnerCity in partnerMergeCities) {
                    if (!Double.IsPositiveInfinity(city.costToGetTo(partnerCity))) {
                        if(thisMergeCity == null && partnerMergeCity == null) {
                            thisMergeCity = city;
                            partnerMergeCity = partnerCity;
                        }
                        else if(city.costToGetTo(partnerCity) < thisMergeCity.costToGetTo(partnerMergeCity)) {
                            thisMergeCity = city;
                            partnerMergeCity = partnerCity;
                        }
                    }
                }
            }

            ArrayList newPartitionCities = new ArrayList();
            // If both merge points are the first in their list
            if (thisMergeCity.Equals(this.partitionSolution.Route[0]) && partnerMergeCity.Equals(mergePartner.PartitionSolution.Route[0])) {
                this.partitionCities.Reverse();
                newPartitionCities.AddRange(this.partitionSolution.Route);
                newPartitionCities.AddRange(mergePartner.PartitionSolution.Route);

            }
            // If this merge point is first and the partner merge point is last
            else if (thisMergeCity.Equals(this.partitionSolution.Route[0]) && partnerMergeCity.Equals(mergePartner.PartitionSolution.Route[mergePartner.PartitionSolution.Route.Count - 1])) {
                newPartitionCities.AddRange(mergePartner.PartitionSolution.Route);
                newPartitionCities.AddRange(this.partitionSolution.Route);
            }
            // If this merge point is last and the partner merge point is first
            else if (thisMergeCity.Equals(this.partitionSolution.Route[this.partitionSolution.Route.Count - 1]) && partnerMergeCity.Equals(mergePartner.PartitionSolution.Route[0])) {
                newPartitionCities.AddRange(this.partitionSolution.Route);
                newPartitionCities.AddRange(mergePartner.PartitionSolution.Route);
            }
            // If this merge point is last and the partner merge point is last
            else if (thisMergeCity.Equals(this.partitionSolution.Route[this.partitionSolution.Route.Count - 1]) && partnerMergeCity.Equals(mergePartner.PartitionSolution.Route[mergePartner.PartitionSolution.Route.Count - 1])) {
                mergePartner.PartitionSolution.Route.Reverse();
                newPartitionCities.AddRange(this.partitionSolution.Route);
                newPartitionCities.AddRange(mergePartner.PartitionSolution.Route);
            }
            this.partitionSolution.Route = newPartitionCities;
            this.partitionCities.AddRange(mergePartner.PartitionCities);
            determineAverageXY();
            return this;
        }

    }
}
