﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace NetworkRouting
{
    class Node
    {
        private int index;              // the index of the point in the array
        private double cost;               // the cost to get to the point
        private Node previous;          // the Node's parent in the tree
        private Boolean visited;
        private PointF nodePoint;       // the point (for drawing)

        // for binary heap implementation
        private int heapIndex;

        // Represents infinity weight for a Node (greater than MAX_WEIGHT)
        public const int INFINITY = 1000000;

        // Constructor
        public Node() {
            this.index = -1;
            this.cost = INFINITY;
            this.previous = null;
            this.visited = false;
            this.nodePoint = new PointF(0, 0);
            this.heapIndex = -1;
        }

        public Node(int index, PointF nodePoint) {
            this.index = index;
            this.cost = INFINITY;
            this.nodePoint = nodePoint;
            this.visited = false;
            this.heapIndex = index + 1;
        }

        // Getters and Setters
        public int getIndex() { return this.index; }
        public int getHeapIndex() { return this.heapIndex; }
        public PointF getPoint() { return this.nodePoint; }
        public double getCost() { return this.cost; }
        public Node getPrevious() { return this.previous; }
        public Boolean hasBeenVisited() { return this.visited; }
        public void setIndex(int index) { this.index = index; }
        public void setHeapIndex(int heapIndex) { this.heapIndex = heapIndex; }
        public void setNodePoint(PointF point) { this.nodePoint = point; }
        public void setCost(double cost) { this.cost = cost; }
        public void setPrevious(Node previous) { this.previous = previous; }
        public void visit() { this.visited = true; }
        public void unvisit() { this.visited = false; }
        // Conditionals (for binary heap)
        public Boolean isRoot() { return this.previous == this; }

    
        // Other functions------------------------------------------------
        // ---------------------------------------------------------------
        // ****************************************************************
        // Calculates and returns the distance from the given node to this node
        //
        public double getDistanceTo(Node node) {
            return Math.Sqrt(Math.Pow((this.nodePoint.X - node.nodePoint.X), 2) + Math.Pow((this.nodePoint.Y - node.nodePoint.Y), 2));
        }

        public PointF getMidPointTo(Node node) {
            float x = this.nodePoint.X / 2 + node.getPoint().X / 2;
            float y = this.nodePoint.Y /2 + node.getPoint().Y / 2;
            return new PointF(x, y);
        }

        // ****************************************************************
        // swaps the heap position of the current node with the given node
        //
        public void swap(Node node) {
            int tempHeapIndex = this.heapIndex;
            this.heapIndex = node.getHeapIndex();
            node.setHeapIndex(tempHeapIndex);   
        }
    }
}
