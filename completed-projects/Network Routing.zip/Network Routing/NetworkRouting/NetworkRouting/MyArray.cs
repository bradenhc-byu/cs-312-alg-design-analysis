﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace NetworkRouting
{
    class MyArray
    {
        // the priority queue (first entry is the weight, second is a visited indicator)
        List<Node> queue;

        // the adjecency list
        List<HashSet<int>> adjacencyList;

        // Constructors -------------------------------------------------------
        public MyArray() {
            this.queue = new List<Node>();
            this.adjacencyList = new List<HashSet<int>>();
        }

        // This constructor is equivalent to a "makequeue()" operation
        public MyArray(List<PointF> points, List<HashSet<int>> adjacencyList, int startNode) {
            this.adjacencyList = adjacencyList;
            this.queue = new List<Node>();
            // First create all the Nodes
            for(int i = 0; i < points.Count; i++) {
                Node node = new Node(i, points[i]);
                this.queue.Add(node);
            }
            // Set the start node's cost to 0 and its previous to itself
            this.queue[startNode].setCost(0);
            this.queue[startNode].setPrevious(this.queue[startNode]);
        }
        // --------------------------------------------------------------------

        // Getters and Setters
        public List<Node> getQueue() { return this.queue; }
        public void setQueue(List<Node> queue) { this.queue = queue; }

        // ********************************************************************
        // DIJKSTRA'S ALGORITHM O(|V|^2)
        // Computes the lowest cost from a the start node to each of the nodes
        // in the queue (array)
        //
        public void runDijkstras() {
            Node pivot = null;
            // Visit every node in the array
            while((pivot = deletemin()) != null) {
                // For each node, look at all of its adjacent nodes
                foreach (int nodeIndex in this.adjacencyList[pivot.getIndex()]) {
                    Node adjacentNode = this.queue[nodeIndex];
                    double newCost = pivot.getCost() + pivot.getDistanceTo(adjacentNode);
                    // If the cost from the pivot node is less than the current cost, adjust
                    if (newCost < adjacentNode.getCost()) {
                        adjacentNode.setCost(newCost);
                        adjacentNode.setPrevious(pivot);
                    }
                }
            }
        }

        // ********************************************************************
        // Array implementation of the deletemin function
        // Returns the minimum Node if it exists, null if all nodes have been visited
        //
        public Node deletemin() {
            Node emptyNode = new Node();
            Node min = emptyNode;
            // Loop through all the nodes and return the node with the lowest cost
            foreach(Node node in this.queue) {
                if (!node.hasBeenVisited() && node.getCost() < min.getCost()) min = node;
            }
            // If all the nodes have been visited, return null
            if (min == emptyNode) return null;
            // otherwise, set the min node's "visited" property to true and return it
            min.visit();
            return min;
        }

        // *********************************************************************
        // Returns the shortest path to the given node by starting at that node
        // and following the train of previous Node pointers until it reaches
        // the start node
        //
        public List<Node> findShortestPathTo(int stopNodeIndex) {
            List<Node> shortestPath = new List<Node>();
            Node currentNode = this.queue[stopNodeIndex];
            Node previousNode = currentNode;
            shortestPath.Add(currentNode);
            // Starting with the destination node, work backwards and
            // visit all of the previous nodes until the source node
            // is reached
            while(!currentNode.isRoot()) {
                shortestPath.Add(currentNode);
                currentNode = currentNode.getPrevious();
                if (currentNode == null) return new List<Node>();
            }
            shortestPath.Add(currentNode);
            return shortestPath;
        }
    }
}
