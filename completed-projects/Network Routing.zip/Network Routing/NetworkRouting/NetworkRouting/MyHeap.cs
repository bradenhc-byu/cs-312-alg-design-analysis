﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace NetworkRouting
{
    class MyHeap
    {
        // the binary heap implementation of the queue
        private List<int> queue;

        // the original list of nodes before the ordering is changed
        private List<Node> originalNodes;

        // the adjacency list for the points
        private List<HashSet<int>> adjacencyList;

        // diagnostics varaibles
        private double totalShortestPathCost;
        
        // Constructors ------------------------------------------------
        public MyHeap() {
            this.queue = new List<int>();
            this.originalNodes = new List<Node>();
            this.adjacencyList = new List<HashSet<int>>();
        }   

        // This implementation of the constructor functions like "makequeue()"
        // NOTE: the queue leaves the entry at 0 empty so that the "bubbleup"
        //       and "bubbledown" parts of the algorithm work
        public MyHeap(List<PointF> points, List<HashSet<int>> adjacencyList, int startNodeIndex) {
            this.adjacencyList = adjacencyList;
            this.queue = new List<int>();
            this.originalNodes = new List<Node>();
            this.queue.Add(-100);
            // makequeue() operation in the algorithm O(|V|)
            for(int i = 1; i <= points.Count; i++) {
                Node node = new Node(i-1, points[i-1]);
                this.queue.Add(i-1);
                this.originalNodes.Add(node);
            }
            // Set the source node
            this.originalNodes[startNodeIndex].setCost(0);
            this.originalNodes[startNodeIndex].setPrevious(this.originalNodes[startNodeIndex]);
            decreasekey(this.originalNodes[startNodeIndex]);
        }

        // Getters and Setters
        public double getShortestPathCost() { return this.totalShortestPathCost; }

        // Other functions ---------------------------------------------
        // *************************************************************
        // DIJKSTRA'S ALGORITHM O( (|V| + |E|) log |V| )
        // Computes the lowest cost from a the start node to each of the nodes
        // in the queue (array)
        //
        public void runDijkstras() {
            Node pivot;
            int iter = 0;
            // Until the queue is empty
            while((pivot = deletemin()) != null) {
                //printQueue(); // used for debugging
                // Visit all of the adjacent nodes and adjust their distances if necessary
                foreach(int nodeIndex in this.adjacencyList[pivot.getIndex()]) {
                    Node adjacentNode = this.originalNodes[nodeIndex];
                    if (adjacentNode == null) continue;
                    double newCost = pivot.getCost() + pivot.getDistanceTo(adjacentNode);
                    // If we need to adjust the distance, do so and then bubble up
                    if(newCost < adjacentNode.getCost()) {
                        adjacentNode.setCost(newCost);
                        adjacentNode.setPrevious(pivot);
                        if(adjacentNode.getHeapIndex() != 1) {
                            decreasekey(adjacentNode);
                        }
                    }
                }
            }

        }

        // USED FOR DEBUGGING - prints the contents of the queue
        private void printQueue() {
            String result = "";
            for (int i = 1; i < this.queue.Count; i++) {
                int index = this.queue[i];
                Node node = getNode(i);
                result = result + " (" + index + "," + node.getCost() + ")";
            }
            Console.WriteLine(result);
        }

        // *************************************************************
        // Binary Heap implementation of the deletemin function
        // Returns the minimum Node if it exists, null if all nodes have
        // been removed from the queue. O(log|V|)
        //
        public Node deletemin() {
            if (this.queue.Count > 1) {
                // Save the min node
                Node min = getNode(1);
                // Set the new root to the last element in the queue
                Node newRoot = getNode(this.queue.Count-1);
                newRoot.setHeapIndex(1);
                this.queue[1] = newRoot.getIndex();
                // Remove the last element
                this.queue.RemoveAt(this.queue.Count - 1);
                // If the child nodes have costs lower than this node, shift
                while (needsShiftDown(newRoot)) {
                    if (needShiftLeft(newRoot)) {
                        Node leftChild = getNode(newRoot.getHeapIndex() * 2);
                        if (leftChild == null) break;
                        swapPointer(newRoot, leftChild);
                    }else if (needShiftRight(newRoot)) {
                        Node rightChild = getNode(newRoot.getHeapIndex() * 2 + 1);
                        if (rightChild == null) break;
                        swapPointer(newRoot, rightChild);
                    }
                }
                return min;
            }
            return null;
        }

        // *************************************************************************
        // Determines if the cost of the given node is less than its children's cost
        // return true if the cost is greater, false otherwise
        //
        private Boolean needsShiftDown(Node node) {
            if (node == null) return false;
            Node leftChild = getNode(node.getHeapIndex() * 2);
            Node rightChild = getNode(node.getHeapIndex() * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return rightChild.getCost() < node.getCost();
            if (rightChild == null) return leftChild.getCost() < node.getCost();
            return (leftChild.getCost() < node.getCost()) || (rightChild.getCost() < node.getCost());
        }

        // ************************************************************************
        // Once we determine the node needs to shift down, determine if the node
        // needs to shift to the left
        // returns true if the node needs to replace the left child, false otherwise
        private Boolean needShiftLeft(Node node) {
            Node leftChild = getNode(node.getHeapIndex() * 2);
            Node rightChild = getNode(node.getHeapIndex() * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return false;
            if (rightChild == null) return true;
            return leftChild.getCost() < rightChild.getCost();
        }

        // ************************************************************************
        // Once we determine the node needs to shift down, determine if the node
        // needs to shift to the right
        // returns true if the node needs to replace the right child, false otherwise
        private Boolean needShiftRight(Node node) {
            Node leftChild = getNode(node.getHeapIndex() * 2);
            Node rightChild = getNode(node.getHeapIndex() * 2 + 1);
            if ((leftChild == null) && (rightChild == null)) return false;
            if (leftChild == null) return true;
            if (rightChild == null) return false;
            return leftChild.getCost() > rightChild.getCost();
        }

        // *************************************************************
        // Binary Heap implementation of the decreasekey function
        // decrements the given node's key and then "bubbles up" the node
        // until it is in the proper order in the heap O(log|V|)
        //
        private void decreasekey(Node node) {
            // if the node's parent has a greater cost than the given node,
            // bubble up
            while (needsShiftUp(node)) {
                Node parent = getNode(node.getHeapIndex() / 2);
                if (parent == null) return;
                swapPointer(node, parent);
            }
        }

        // ***************************************************************
        // Determines of the parent node of the given node has a greater cost
        // returns true if the parent node cost is greater, false otherwise
        //
        private Boolean needsShiftUp(Node node) {
            if (node == null) return false;
            if (node.getHeapIndex() == 1) return false; // it's the root
            Node parent = getNode(node.getHeapIndex() / 2);
            if (parent == null) return false;
            return parent.getCost() > node.getCost();
        }

        // ********************************************************************
        // swaps two nodes in the queue (bubble up or down) O(1)
        //
        private void swapPointer(Node node1, Node node2) {
            this.queue[node1.getHeapIndex()] = node2.getIndex();
            this.queue[node2.getHeapIndex()] = node1.getIndex();
            node1.swap(node2);
        }

        // ********************************************************************
        // Returns the node associated with the given heap index
        // Used to reference the node associated with the current heap index
        // (1 to 1 mapping) O(1)
        //
        private Node getNode(int heapIndex) {
            if ((heapIndex > 0) && (heapIndex < this.queue.Count)) {
                return this.originalNodes[this.queue[heapIndex]];
            }
            return null;
        }

        // *********************************************************************
        // Returns the shortest path to the given node by starting at that node
        // and following the train of previous Node pointers until it reaches
        // the start node
        //
        public List<Node> findShortestPathTo(int stopNodeIndex) {
            List<Node> shortestPath = new List<Node>();
            Node currentNode = this.originalNodes[stopNodeIndex];
            this.totalShortestPathCost = currentNode.getCost();
            Node previousNode = currentNode;
            // Starting from the destination node
            while (!currentNode.isRoot()) {
                // add the node to the shortest path
                shortestPath.Add(currentNode);
                // switch to the node that points to this one
                currentNode = currentNode.getPrevious();
                if (currentNode == null) return new List<Node>();
            }
            shortestPath.Add(currentNode);
            return shortestPath;
        }

    }
}
