﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSP {
    class State {

        // Domain variables with assocaited accessors

        // The level at which the state exists
        private int level;
        public int Level {
            get { return level; }
            set { level = value; }
        }

        // The Cost Matrix Associated with this state
        // Rows: From city
        // Columns: To city
        private double[,] costMatrix;
        public double[,] CostMatrix {
            get { return costMatrix; }
            set { costMatrix = value; }
        }

        // The lower bound estimations for this state
        private double bound;
        public double Bound {
            get { return bound; }
            set { bound = value; }
        }

        // The index representing the location of the 
        // city this state is associated with in the Cities array
        private int cityIndex;
        public int CityIndex {
            get { return cityIndex; }
            set { cityIndex = value; }
        }

        // The route of the state representing a partial or
        // complete solution
        private System.Collections.ArrayList route;
        public System.Collections.ArrayList Route {
            get { return route; }
            set { route = value; }
        }

        // The ratio that is used to determine the priority level
        // of the state
        private double pRatio;
        public double PRatio {
            get { return pRatio; }
        }

        // The index of the state in the priority queue
        private int queueIndex;
        public int QueueIndex {
            get { return queueIndex; }
            set { queueIndex = value; }
        }

        // **************************************************************
        // CONSTRUCTORS
        // **************************************************************
        // Default Constructor
        //
        public State() {
            this.level = 0;
            this.cityIndex = -1;
            this.route = new System.Collections.ArrayList();
            this.costMatrix = null;
            this.bound = 0;
            this.pRatio = -1.0;
        }

        // Constructor for the beginning state
        //
        public State(int cityIndex, double[,] costMatrix) {
            this.level = 0;
            this.cityIndex = cityIndex;
            this.route = new System.Collections.ArrayList();
            this.route.Add(cityIndex);
            this.costMatrix = costMatrix;
            // Reduce the matrix without removing rows or columns
            initializeMatrix(-1);
            this.pRatio = 1.0;
        }

        // Constructor for generated children states
        // Overall Time, Space Complexity: O(n^2)
        //
        public State(State parentState, int cityIndex) {
            this.level = parentState.Level + 1;
            this.cityIndex = cityIndex;
            this.route = new System.Collections.ArrayList(parentState.Route);
            this.route.Add(cityIndex);
            this.costMatrix = copyMatrix(parentState.CostMatrix);
            this.bound = parentState.bound;
            // Reduce the matrix for this state
            initializeMatrix(parentState.CityIndex);
            // Determine the priority level
            this.pRatio =  (1.0/this.bound) * this.level;
        }

        // ****************************************************************************
        // Takes the matrix inherited from the parent (or start) and sets it up for this
        // state
        // Time Complexity: O(4n^2)
        // Space Complexity: O(n^2)
        //
        private void initializeMatrix(int parentCityIndex) {
            int row, col;
            if(parentCityIndex != -1) {

                // Initialize entries at departure city (parent, make infinity)
                for (col = 0; col < this.CostMatrix.GetLength(1); col++) {
                    this.costMatrix[parentCityIndex, col] = Double.PositiveInfinity;
                }

                // Initialize entries for the destination city (this, make infinity)
                for (row = 0; row < this.CostMatrix.GetLength(0); row++) {
                    this.costMatrix[row, this.cityIndex] = Double.PositiveInfinity;
                }

                // Initialize the entry back to the parent
                this.costMatrix[this.cityIndex, parentCityIndex] = Double.PositiveInfinity;

            }

            // Reduce the rows and columns in the matrix
            reduceMatrix();
        }

        // **************************************************************************
        // Reduces this state's matrix
        // Time Complexity: O(2n^2)
        // Space Complexity: O(n^2)
        //
        private void reduceMatrix() {
            double minCost = Double.MaxValue;       // The minimum cost of the row/col
            bool reduced = false;                   // Flag for detecting reduced rows
            int infinityCount = 0;                  // Helps check for invalid rows/cols
            // Reduce all of the rows
            for(int row = 0; row < this.costMatrix.GetLength(0); row++) {
                for(int col = 0; col < this.costMatrix.GetLength(1); col++) {
                    if(!Double.IsPositiveInfinity(this.costMatrix[row, col])) {
                        if (this.costMatrix[row, col] == 0.0) {
                            reduced = true;
                            break;
                        }
                        // Compare costs to determine the min
                        minCost = Math.Min(minCost, this.costMatrix[row, col]);
                    }
                    else {
                        // If this count reaches the length of a row/col in the matrix,
                        // then we know the row is all infinity and is thus invalid
                        // for reduction
                        infinityCount++;
                    }
                }
                if (!reduced && infinityCount != this.costMatrix.GetLength(0)) {
                    // The row needs a reduction
                    this.bound += minCost;
                    for (int col = 0; col < this.costMatrix.GetLength(1); col++) {
                        this.costMatrix[row, col] = this.costMatrix[row, col] - minCost;
                    }
                }
                reduced = false;
                minCost = Double.MaxValue;
                infinityCount = 0;
            }

            reduced = false;
            minCost = Double.MaxValue;
            infinityCount = 0;
            // Reduce all of the columns
            for (int col = 0; col < this.costMatrix.GetLength(1); col++) {
                for (int row = 0; row < this.costMatrix.GetLength(0); row++) {
                    if(!Double.IsPositiveInfinity(this.costMatrix[row, col])) {
                        if (this.costMatrix[row, col] == 0.0) {
                            reduced = true;
                            break;
                        }
                        // Compare costs to determine the min
                        minCost = Math.Min(minCost, this.costMatrix[row, col]);
                    }
                    else {
                        infinityCount++;
                    }
                }
                if (!reduced && infinityCount != this.costMatrix.GetLength(1)) {
                    // The col needs a reduction
                    this.bound += minCost;
                    for (int row = 0; row < this.costMatrix.GetLength(0); row++) {
                        this.costMatrix[row, col] = this.costMatrix[row, col] - minCost;
                    }
                }
                reduced = false;
                minCost = Double.MaxValue;
                infinityCount = 0;
            }
        }

        // **************************************************************************************
        // Performs a deep copy of a cost matrix - used to inherit a parent matrix
        // Time, Space complexity: O(n^2)
        //
        private double[,] copyMatrix(double[,] origCostMatrix) {
            double[,] myCostMatrix = new double[origCostMatrix.GetLength(0), origCostMatrix.GetLength(1)];
            // Copy all the entries of the parent matrix into the this state's matrix
            for(int row = 0; row < origCostMatrix.GetLength(0); row++) {
                for(int col = 0; col < origCostMatrix.GetLength(1); col++) {
                    myCostMatrix[row, col] = origCostMatrix[row, col];
                }
            }

            return myCostMatrix;
        }
    }
}