﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Primality_Tester
{
    public partial class PrimalityTester : Form{
        public PrimalityTester(){
            InitializeComponent();
        }

        /*
            * Determines whether the number entered in to the input text field 
            * of the application is a prime number or not
            * Complexity: O(n^3)
            * NOTE: Complexity can increase depending on the method by which 
            *       you choose to generate
            *       your random number
        */
        private void solve_click(object sender, EventArgs e){   
            //Set the primality flag to true
            bool isPrime = true;

            //Set the probability given the 'k' value with a default 
            //value of 5 ( 1 / (2^k) )
            int k_num = 5;
            if (!k.Text.Equals("")){
                k_num = Convert.ToInt32(k.Text);
            }
            double ratio = 1 / (Math.Pow(2.0, (double)k_num));
            double probability = Math.Round((double)(1 - ratio),5);

            //Set the input number
            int inputNum = Convert.ToInt32(input.Text);

            //Test for primality until 'k' iterations have passed 
            //( Complexity: O(n^3) )
            Random rand = new Random();
            while (k_num-- != 0){

                //Pick a random number 
                int a = rand.Next(1,inputNum);

                //Determine the value of the modular exponentiation (gcd) 
                //( Complexity: O(n^3) )
                int gcd = modexp(a, inputNum - 1, inputNum);

                //Check the remainder. If it is not 1, then the number is 
                //not prime, so we break the loop to avoid unneccesary cycles
                //This is representation of the greatest common divisor
                if(gcd != 1)
                {
                    isPrime = false;
                    break;
                }
            }

            //Dispay the result in the output text box
            output.Text = isPrime ? "yes with " + probability + " probability" : "no";
        }

        /*
            * Computes the modular exponentiation of x^y mod n using recursion
            * Complexity: O(n^3)
        */
        private int modexp(int x, int y, int n){
            //Recursive algorithm. If the base case is reached, return 1
            if (y == 0) return 1;

            int z = modexp(x, y / 2, n);
            //If the number is even, return z^2 mod n
            if (y % 2 == 0) return (int)(Math.Pow((double)z, 2.0) % n);
            //If the number is odd, return x * z^2 mod n
            else return (int)((x * Math.Pow((double)z, 2.0)) % n);
        }

        private void PrimalityTester_Load(object sender, EventArgs e){

        }

    }
}
